<?php $IEM = $tpl->Get('IEM'); ?><div class='FlashSuccess'>
	<img src='images/success.gif' width='18' height='18' align='left' class='FlashSuccess' /> <?php if(isset($GLOBALS['Success'])) print $GLOBALS['Success']; ?>
</div>
