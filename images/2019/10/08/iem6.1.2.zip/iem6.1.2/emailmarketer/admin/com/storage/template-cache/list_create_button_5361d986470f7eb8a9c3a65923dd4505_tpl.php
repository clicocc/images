<?php $IEM = $tpl->Get('IEM'); ?><input type="button" name="AddListButton" value="<?php print GetLang('CreateListButton'); ?>" style="width:150px" class="SmallButton" onclick="javascript: document.location='index.php?Page=lists&Action=create';">

