<?php $IEM = $tpl->Get('IEM'); ?><div id="NoItem_id" style="padding:2px 0px; color:#636363;">
			<?php echo $tpl->Get('page','message'); ?>
</div>
