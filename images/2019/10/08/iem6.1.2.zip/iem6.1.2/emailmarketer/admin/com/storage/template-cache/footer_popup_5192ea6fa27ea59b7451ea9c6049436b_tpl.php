<?php $IEM = $tpl->Get('IEM'); ?><!-- END PAGE FOOTER -->
</div>
</body>
</html>
