<?php
/**
* Language file for installer.
* This is here as a placeholder only.
* You can't change the language variables for the installer.
*
* @package SendStudio
* @subpackage Language
*/

/**
* You can't change the language variables for the installer.
*/

?>
