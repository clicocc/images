<?php
if (!defined('SENDSTUDIO_BASE_DIRECTORY')) {
	header('Location: ../../index.php');
	exit;
}
